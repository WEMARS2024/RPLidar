//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by framegrabber.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_DLG_SERIAL_SEL              201
#define IDD_DLG_SETFREQ                 203
#define IDD_IP_CONFIG                   206
#define IDD_DLG_CHOOSE_CONNECTION       208
#define IDD_DLG_AUTO_DISCOVERY          209
#define IDC_EDIT1                       1020
#define IDC_BUTTON_FREQ_SET             1022
#define IDC_SLIDER_FREQ                 1023
#define IDC_STATIC_MINFREQ              1024
#define IDC_STATIC_MAXFREQ              1025
#define IDC_EDIT_FREQ                   1026
#define IDC_LIST1                       1031
#define IDC_CONFIG_IP                   1031
#define IDC_LIST_IP                     1031
#define IDC_CONFIG_MASK                 1032
#define IDC_CONFIG_GATEWAY              1033
#define IDC_DHCP_CLIENT                 1036
#define IDC_RADIO_VIA_SERIAL_PORT       1037
#define IDC_COMBO_SERIAL_PORT           1040
#define IDC_COMBO_SERIAL_BAUD           1041
#define IDC_RADIO_VIA_NETWORK           1042
#define IDC_IPADDRESS                   1043
#define IDC_EDIT3                       1044
#define IDC_IP_PORT                     1044
#define IDC_EDIT_DEV_TYPE               1044
#define IDC_COMBO_NETWORK_PROTOCOL      1045
#define IDC_BUTTON_AUTO_DISCOVERY       1046
#define IDC_IPADDRESS_SEL               1047
#define IDC_EDIT_IP_PORT                1048
#define IDC_BTN_REFRESH                 1049
#define ID_CMD_GRAB_FRAME               32776
#define ID_CMD_SCAN                     32780
#define ID_CMD_GRAB_PEAK                32781
#define ID_COMMAND_STARTGRABFRAME       32782
#define ID_COMMAND_SCAN                 32783
#define ID_COMMAND_GRABPEAK             32784
#define ID_CMD_RESET                    32785
#define ID_COMMAND_RESET                32786
#define ID_COMMAND_GETCALIBRATIONINFO   32787
#define ID_CMD_                         32788
#define ID_CMD_STOP                     32790
#define ID_COMMAND_STOP                 32791
#define ID_OPTION_FORCESCAN             32793
#define ID_OPT_FORCESCAN                32794
#define ID_FILE_DUMPDATA                32795
#define ID_COMMAND_GRABFRAMENONEDIFF    32797
#define ID_CMD_GRABFRAMENONEDIFF        32798
#define ID_CMD_SET_FREQ                 32799
#define ID_OPTION_EXPRESSMODE           32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
